package com.cg.controller;

import com.cg.servlet.HttpServletRequest;
import com.cg.servlet.HttpServletResponse;
import com.cg.servlet.IOException;
import com.cg.servlet.RequestDispatcher;
import com.cg.servlet.ServletException;
import com.cg.servlet.String;
import com.cg.servlet.WebServlet;

@WebServlet("/MobileController")
public class MobileController {

	public MobileController() {
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long mId =  Long.parseLong(request.getParameter("mobileId"));
		String mName = request.getParameter("mobileName");
        String mModel =  request.getParameter("mobileModel");
        int MfgYear = Integer.parseInt(request.getParameter("manufactureYear")) ;
        long mPrice=Long.parseLong(request.getParameter("mobilePrice"));
        // Mobile Id, Mobile Name, Mobile Model, Mobile MfgYear(drop down), Mobile Price. 
        
        
        if((String.valueOf(mId).length()==4 && mName.equals("IPhone"))&&(mPrice<=12000))
        {
            RequestDispatcher rd = request.getRequestDispatcher("SuccessPurchase.jsp");
            rd.forward(request,response);
        }
        else
        {
            RequestDispatcher rd = request.getRequestDispatcher("FailurePurchase.jsp");
            rd.forward(request,response);
        }
	}
}
