package com.cg.main;

import com.cg.bean.PizzaBean;


public class PizzaMain {
	public static void main(String[] args) {
		EntityManagerFactory  emf=Persistence.createEntityManagerFactory("JPA_PizzaOrderDelivery");
		EntityManager em=emf.createEntityManager();
		
		PizzaBean pB=new PizzaBean();
		pB.setExtraCheese(true);
		pB.setPizzaType("AllInOne");
		pB.setQuantity(24);
		pB.setTotalPrice(pB.getQuantity(), pB.isExtraCheese());
		
		em.getTransaction().begin();
		em.persist(pB);
		em.getTransaction().commit();
		System.out.println("Data Saved");
	}
}
