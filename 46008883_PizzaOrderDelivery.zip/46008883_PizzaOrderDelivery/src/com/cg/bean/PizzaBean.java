package com.cg.bean;

import java.io.Serializable;





@Entity
public class PizzaBean implements Serializable {
	// Order Id auto generated ,pizza_type, extra_Cheese, quantity, totalPrice from user
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	private String pizzaType;
	private boolean extraCheese;
	private double quantity;
	private double totalPrice;
	
	public PizzaBean() {
		
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getPizzaType() {
		return pizzaType;
	}

	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}

	public boolean isExtraCheese() {
		return extraCheese;
	}

	public void setExtraCheese(boolean extraCheese) {
		this.extraCheese = extraCheese;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double quantity,boolean extraCheese) {
		int eCheese=100;
		if(extraCheese) {
			this.totalPrice =eCheese+(quantity*12) ;
		} else {
			this.totalPrice=quantity*12;
		}
		
	}
	
	
}
